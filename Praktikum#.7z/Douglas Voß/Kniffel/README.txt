Anweisungen zur Praktikantenaufgabe (Kniffel)
=============================================


A. Bitte f�hren Sie die Entwicklung des vorgegebenen Kniffel Spiels fort.

	Die Vorgabe bietet Ihnen bereits folgende Funktionalit�ten:

		1. W�rfeln: Jeder der f�nf W�rfel zeigt eine Zufallszahl zwischen 1 und 6 an (wird im Attribut "value" geschrieben).

		2. W�rfel halten: Mit einem Klick auf einen W�rfel wird dieser gehalten oder losgelassen (wird im Attribut "data-hold" gekennzeichnet).

		3. Die aktuellen W�rfel k�nnen f�r Einser und Zweier zugewiesen werden (Klick auf das jeweilige Punktefeld).

		4. Die Gesamtpunktzahl wird erh�ht.

	Folgende Funktionalit�ten fehlen oder sind zu erweitern. Bitte beachten Sie alle "@TODO" Kommentare in kniffel.html, script.js und style.css.

		1. Wird ein W�rfel gehalten, darf dieser nicht gew�rfelt werden, wenn man auf den Button "W�rfeln" klickt.

		2. Wurde ein Punktefeld bereits ausgew�hlt, z.B. Einser, darf man hier kein weiteres mal Punkte zuweisen.

		3. Pro Runde sind maximal drei W�rfe erlaubt. Sp�testens jetzt m�ssen die W�rfel einem freien Punktefeld zugewiesen werden.

		4. Zentrieren Sie den "W�rfeln" Button.

		5. Zeigen Sie auch f�r Tabellenzellen einen Rahmen an.

		6. Erweitern Sie die Wertetabelle und Funktionalit�t, damit auch Dreier, Vierer, F�nfer und Sechser ausgew�hlt werden k�nnen.

		7. Verhindern Sie, dass die W�rfel gehalten oder losgelassen werden k�nnen, bevor mindestens einmal gew�rfelt wurde.

		9. Setzen Sie die Anzahl der get�tigten W�rfe zur�ck, wenn eine Runde beendet wurde.

		10. Berechnen Sie einen Dreier- und Viererpasch.


B. Ihnen ist es nat�rlich erlaubt, weitere HTML Elemente, Styles und Javascript Variablen oder Funktionen hinzuzuf�gen oder bestehende zu �ndern.

	Auch d�rfen Sie das Kniffel Spiel versuchen komplett fertigstellen, wenn Ihnen die Aufgabe zu leicht erscheint oder sehr viel Spa� macht!

	Weitere M�glichkeiten w�ren:

		1. Wertetabelle erweitern und Punkte berechnen f�r: Full House, Kleine Stra�e, Gro�e Stra�e, Kniffel, Chance.

		2. Wenn die Gesamtsumme der eingetragenen Punkte f�r Einser bis Sechser mindestens 63 ist, erh�lt man 35 Bonuspunkte.

	Eine funktionierende Kniffel Demo k�nnen Sie unter folgender URL finden (dient nur zur Veranschaulichung und Verst�ndnis des Spiels):

	http://onlinespiele.schmidtspiele.de/game/sp/platform/schmidt/


C. Sollten Ihnen Konstrukte im HTML, CSS oder Javascript unbekannt sein, k�nnen Sie z.B. im Internet Informationen dazu finden. Wir empfehlen:

	http://www.w3schools.com


D. Sonstiges zur Bearbeitung und Anwendung.

	1. �ffnen Sie kniffel.html in einem beliebigen Browser, um das Spiel zu starten.

	2. Nutzen Sie einen beliebigen Texteditor um �nderungen an den Dateien kniffel.html, script.js und style.css vorzunehmen. Wir empfehlen:

		https://notepad-plus-plus.org/

	3. Sie k�nnen �ber die Taste F12 in den meisten modernen Browsern die Entwicklungskonsole �ffnen und damit leichter testen und ausprobieren.

	4. Die Kommentare in kniffel.html, script.js und style.css sollen Ihnen helfen, die betreffenden Zeilen zu verstehen.

	5. Die Fertigstellung des Spiels ist nicht Pflicht!

		Sollten Sie an einen Punkt gelangen, an dem Sie nicht mehr weiterkommen, senden Sie uns einfach Ihren aktuellsten Stand zu.


Wir w�nschen Ihnen viel Spa� und Erfolg bei dieser Aufgabe!

Ihr EGOTEC GmbH Team
