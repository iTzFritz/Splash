var wh = 50;
var sElement = 3; // 1- Wand // 2 - Geist // 3 - Pacman
var mouseX=null, mouseY=null;

var Enemy = [];
var Geister = [];
var Walls = [];
var Pac = null;

function Pacman(y,x) {

	this.node = document.createElement('div');
	this.node.className = 'pacman';
	this.node.style.left = (x * wh) + 'px';
	this.node.style.top = (y * wh) + 'px';
	
	world.appendChild(this.node);
};

function Ghost(farbe,y,x) {
	var t = this;
	this.x = x;
	this.y = y;
	this.farbe = farbe;
	
	this.node = document.createElement('div');
	this.node.className = 'enemy';
	this.node.style.backgroundColor = this.farbe;
	this.node.style.left = (this.x * wh) + 'px';
	this.node.style.top = (this.y * wh) + 'px';
	world.appendChild(this.node);
	
	Geister.push(this.node);
}

function Wall(farbe,y,x) {
	this.x = x;
	this.y = y;
	this.farbe = farbe;
	
	this.node = document.createElement('div');
	this.node.className = 'feld wand';
	this.node.style.backgroundColor = this.farbe;
	this.node.style.left = (this.x * wh) + 'px';
	this.node.style.top = (this.y * wh) + 'px';
	world.appendChild(this.node);
	
	Walls.push(this.node);
}




var map =	[
			[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
			[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
			];

			
function displayMap() {
	var world = document.getElementById('world');
	

	for (var y = 0; y < map.length; y++) {
		for(var x = 0; x < map[y].length; x++) {
			var feld = document.createElement('div');
			feld.className = 'feld';
			
			feld.style.left = (x * wh) + 'px';
			feld.style.top = (y * wh) + 'px';
			
			world.appendChild(feld);
			
			if (map[y][x] == 1) {
				Walls.push(new Wall("blue",y,x));
			}
			
			else if (map[y][x] == 2) {
				Pac = new Pacman(y,x);
			}
			
			else if(map[y][x] == 3) {
				Enemy.push(new Ghost("red",y,x));
			}
			
			else if(map[y][x] == 0) {
			}
		}
	}
}

function displayMenu() {
	var wrapper = document.createElement('div');
	var scoreboard = document.createElement('div');
	var menu = document.getElementById("menu");
	
			
	wrapper.className = 'menu';
	scoreboard.innerHTML = ("1 : Wand<br><br>2: Geist<br><br>3: Pacman");
			
	wrapper.appendChild(scoreboard);
	menu.appendChild(wrapper);	
}

window.onload = function() {
	displayMap();
	displayMenu();
	
	addEventListener("click",function(e) {
	
		mouseX = parseInt(e.clientX / wh); // Math.round(), Math.floor(), Math.ceil()
		mouseY = parseInt(e.clientY / wh);
		
		
		if(sElement == 1) { // Wand
			if(map[mouseY][mouseX]==0) { 
				map[mouseY][mouseX]= 1; console.debug("Wand gesetzt"); 
				Walls.push(new Wall("blue",mouseY,mouseX));
			}
			
			
			else if(map[mouseY][mouseX]== 1) { 
				map[mouseY][mouseX]= 0; console.debug("Wand entfernt"); 
				
				for(var i= 0; i < Walls.length; i++) {
					if((Walls[i].y == mouseY) && (Walls[i].x == mouseX)) {
						world.removeChild(Walls[i].node);
						break;
					}
				}
			}
			
		}
		
		else if(sElement == 2) { //Geist
			if( map[mouseY][mouseX]==0) { 
				map[mouseY][mouseX]= 3; console.debug("Geist gesetzt"); 
				
				Enemy.push(new Ghost("red",mouseY,mouseX));
			}
			
			else if(map[mouseY][mouseX]==3) { 
				map[mouseY][mouseX]= 0; console.debug("Geist entfernt"); 
				
				for(var i= 0; i < Enemy.length; i++) {
					if((Enemy[i].y == mouseY) && (Enemy[i].x == mouseX)) {
						world.removeChild(Enemy[i].node);
						break;
					}
				}
			}
		}
		
		else if(sElement == 3) { //Pacman
			if( map[mouseY][mouseX]==0 && Pac == null) { 
				map[mouseY][mouseX]= 2; console.debug("Pacman gesetzt"); 
				
					Pac = new Pacman(mouseY,mouseX);
			}
			
			else if( map[mouseY][mouseX]==2) { 
				map[mouseY][mouseX]= 0; console.debug("Pacman entfernt"); 
				
				world.removeChild(Pac.node);
				Pac = null;
			}
		}
		
	addEventListener("keydown",function(e) {
		if(e.keyCode==13) {
		
			localStorage.setItem("maps",JSON.stringify(map));
			console.log("Map gespeichert");
		}
		
		else if(e.keyCode==49) { //1
			sElement = 1;
		}
		
		else if(e.keyCode==50) { //2
			sElement = 2;
		}
		
		else if(e.keyCode==51) { //3
			sElement = 3;
		}
		
		
	},false);
		
		
	}, false);

};