var wh = 50;
var keyhold = false;
var sElement = 2; // 1- Wand // 2 - Geist

var Pacman = {};
var Enemy = [];
var Points = [];
var Felder = [];
var punkteScore = 0;

var world;

var gameover = false;

function Ghost(farbe,y,x) {
	var t = this;
	this.x =x;
	this.y = y;
	this.node;
	this.last = 0;
	this.farbe = farbe;
	
	this.node = document.createElement('div');
	this.node.className = 'enemy';
	this.node.style.backgroundColor = this.farbe;
	this.node.style.left = (this.x * wh) + 'px';
	this.node.style.top = (this.y * wh) + 'px';
	world.appendChild(this.node);
}

Ghost.prototype.move = function() {
	var temp = this;
	
	setTimeout(function() {
		var valid_zahl = false;
		var retry = 2;
		do {
			var zahl = Math.floor(Math.random() * (40 - 37 + 1)) + 37; //37 - links, 38 - oben, 39 - rechts, 40 - unten
			var x = parseInt(temp.node.style.left) / wh;
			var y = parseInt(temp.node.style.top) / wh;

			switch (zahl) {
				case 37:
					if(map[y][x-1]==1 || (temp.last && temp.last == 39 && --retry > 0)) {
						continue;
					}
					break;
				case 38:
					if(map[y-1][x]==1 || (temp.last && temp.last == 40 && --retry > 0)) {
						continue;
					}
					break;
				case 39:
					if(map[y][x+1]==1 || (temp.last && temp.last == 37 && --retry > 0)) {
						continue;
					}
					break;
				case 40:
					if(map[y+1][x]==1 || (temp.last && temp.last == 38 && --retry > 0)) {
						continue;
					}
			}
			
			valid_zahl = true;
		} while (!valid_zahl);
			
		temp.last = zahl;
		moveElement(temp.node,zahl);
		temp.move();
	}, 1000);
}


var map =	[
			[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
			[1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1],
			[1,0,1,1,0,1,1,1,0,1,1,0,0,1,1,1,0,1,0,1],
			[1,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,1,0,1],
			[1,0,1,1,0,1,0,0,1,1,1,1,1,0,1,0,1,1,0,1],
			[1,0,1,0,0,1,1,0,0,0,1,3,0,0,1,0,0,0,0,1],
			[1,0,0,0,0,1,0,0,1,0,1,3,1,0,1,1,0,1,0,1],
			[1,1,1,1,0,0,0,0,1,0,1,0,1,0,0,0,0,1,0,1],
			[1,0,1,0,0,1,0,1,1,0,0,0,1,1,0,1,1,1,0,1],
			[1,0,0,0,1,1,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
			[1,0,1,0,0,1,0,1,0,1,1,1,0,1,0,1,0,1,0,1],
			[1,0,1,0,0,0,0,1,0,0,0,0,0,1,0,1,0,0,0,1],
			[1,0,1,1,1,0,1,1,1,0,1,0,1,1,0,1,1,0,1,1],
			[1,0,0,0,0,3,1,3,0,0,1,3,0,0,0,0,0,0,1,1],
			[1,0,1,1,0,0,0,0,0,1,1,1,0,1,1,1,0,1,1,1],
			[1,0,1,0,0,1,1,1,0,0,1,0,0,0,0,0,0,0,0,1],
			[1,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,1,1,0,1],
			[1,0,0,0,1,0,0,0,1,0,0,1,1,1,0,1,0,1,0,1],
			[1,0,0,1,1,1,0,1,1,1,0,0,0,0,0,0,0,0,0,1],
			[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
			];

			
			
function displayMap() {
	world = document.getElementById('world');
	
	world.style.width = (map[0].length * wh) + 'px';
	world.style.height = (map.length * wh) + 'px';

	for (var y = 0; y < map.length; y++) {
		for(var x = 0; x < map[y].length; x++) {
			var feld = document.createElement('div');
			feld.className = 'feld';
			
			feld.style.left = (x * wh) + 'px';
			feld.style.top = (y * wh) + 'px';
			
			world.appendChild(feld);
			Felder.push(feld);
			
			
			if (map[y][x] == 1) {
				feld.className = 'feld wand';
			}
			
			if (map[y][x] == 0) {
				var point = document.createElement('div');
				point.className = 'point';
				
				point.style.left = (x * wh) + 'px';
				point.style.top = (y * wh) + 'px';
				
				world.appendChild(point);
				Points.push(point);
			}
			
			if (map[y][x] == 2) {
				Pacman.node = document.createElement('div');
				Pacman.node.className = 'pacman';
				
				Pacman.node.style.left = (x * wh) + 'px';
				Pacman.node.style.top = (y * wh) + 'px';
				
				world.appendChild(Pacman.node);
			}
			
			if(map[y][x] == 3) {
				Enemy.push(new Ghost("red",y,x));
			}
		}
	}
}

function displayScore() {
	
	var wrapper = document.createElement('div');
	var scoreboard = document.createElement('div');
	var score = document.getElementById("score");
	
			
	wrapper.className = 'scoreboard';
	scoreboard.innerText = ('Score: '+punkteScore);

	score.innerHTML = '';
	wrapper.appendChild(scoreboard);
	score.appendChild(wrapper);
			
}

function moveElement(element, direction) {
	if (gameover) {
		return;
	}

	var x = parseInt(element.style.left) / wh;
	var y = parseInt(element.style.top) / wh;

	if (keyhold == false || element != Pacman.node) {
		if(direction==37 && map[y][x - 1] != 1) { //links
			element.style.left = ((x - 1) * wh) + 'px';
			keyhold = true;
		}
		
		if(direction==39 && map[y][x + 1] != 1) { //rechts
			element.style.left = ((x + 1) * wh) + 'px';
			keyhold = true;
		}
		
		if(direction==38 && map[y - 1][x] != 1) { //oben
			element.style.top = ((y - 1) * wh) + 'px';
			keyhold = true;
		}
		
		if(direction==40 && map[y + 1][x] != 1) { //unten
			element.style.top = ((y + 1) * wh) + 'px';
			keyhold = true;
		}
	}
	
	kollision();
}
		
function kollision() {
	for(var i=0;i < Enemy.length;i++) {
		if(Pacman.node.style.left == Enemy[i].node.style.left && Pacman.node.style.top == Enemy[i].node.style.top) {
			var wrapper = document.createElement('div');
			var message = document.createElement('div');
			
			wrapper.className = 'message';
			message.innerText = 'Verloren';
			
			wrapper.appendChild(message);
			world.appendChild(wrapper);
			
			gameover = true;
			break;
		}
	}
	
	for(var i=0;i < Points.length;i++) {
		if(Points[i].parentNode && Pacman.node.style.left == Points[i].style.left && Pacman.node.style.top == Points[i].style.top) {
			world.removeChild(Points[i]);
			
			
			punkteScore++;
			displayScore();
			
			if(punkteScore == Points.length) {
				var wrapper = document.createElement('div');
				var message = document.createElement('div');
				
				wrapper.className = 'message';
				message.innerText = 'Gewonnen';
				
				wrapper.appendChild(message);
				world.appendChild(wrapper);
				
				gameover = true;
				break;
			}
			
			break;
		}
	}
}

window.onload = function() {

	
	if(localStorage.getItem("maps")===null) {
		
	}
	
	else {
		map = JSON.parse(localStorage.getItem("maps"));
	}

	displayMap();
	displayScore();
	var pacman = document.getElementById("pacman");

	addEventListener("keydown",function(e) {
		moveElement(Pacman.node, e.keyCode);
		
		if(e.keyCode==13) { window.localStorage.clear(); location.reload(); }
	}, false);
	
	addEventListener("keyup",function(e) {
		keyhold = false;
	}, false);
	
	for(var i=0;i<Enemy.length;i++) {
		Enemy[i].move();
	}
};