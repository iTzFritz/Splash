/**
 * Gesamtpunktzahl
 *
 * @var number
 */
var score = 0;

/**
 * Anzahl der get�tigten W�rfe in dieser Runde
 *
 * @var number
 */
var rolled = 0;

/**
 * Alle aktuellen W�rfelwerte
 *
 * @var array
 */
var values = [];

/**
 * Variable zum z�hlen der 3 Durchg�nge
 *
 * @var number
 */
var turned = 0;

var oberePunktzahl = 0; // N�tig f�r den Bonus 
var playerScore = null;

window.onload = writeBestenliste;

/**
 * Alle W�rfel werfen
 *
 * @return void
 */
function rollDices() {

	if(turned==3&&rolled>0)
	{
		return;
	} else {
		turned++;
	}

	// Alle HTML Elemente mit der CSS Klasse "dice" ermitteln
	var dices = document.getElementsByClassName('dice');

	// Die aktuellen W�rfelwerte zur�cksetzen
	values = [];

	for (var i = 0; i < dices.length; i++) {

		// @TODO W�rfel nicht w�rfeln, wenn dieser gehalten wird
		if(dices[i].getAttribute('data-hold'))
		{
			var value = parseInt(dices[i].value);
			values.push(value);
			continue;
		}

		// Eine Zufallszahl zwischen 1 und 6 generieren und dem W�rfel zuweisen
		dices[i].value = Math.floor((Math.random() * 6) + 1);

		// Aktuellen W�rfelwert merken
		var value = parseInt(dices[i].value);
		values.push(value);
	} 

	// Anzahl der get�tigten W�rfe erh�hen
	rolled++;
}

/**
 * W�rfel einem Feld zuweisen
 *
 * @param HTMLElement field
 * @param mixed type
 * @return void
 */
function assignDices(field, type) {

	// @TODO Verhindern Sie, dass die W�rfel einem Feld mehr als einmal zugewiesen werden k�nnen
	if(field.innerHTML=="----"||field.innerHTML>0)
	{
		return;
	}

	// Die zu vergebenden Punkte
	var points = 0;

	// Punkte berechnen
	switch (type) {
		// Einser bis Sechser @TODO Erweitern Sie, damit auch Dreier, Vierer, F�nfer und Sechser berechnet werden
		case 1:
			points = getEinserBisSechser(type);
			break;

		case 2:
			points = getEinserBisSechser(type);
			break;

		case 3:
			points = getEinserBisSechser(type);
			break;

		case 4:
			points = getEinserBisSechser(type);
			break;

		case 5:
			points = getEinserBisSechser(type);
			break;

		case 6:
			points = getEinserBisSechser(type);
			break;

		case 'Dreierpasch':
			points = getPasch(3);
			break;

		case 'Viererpasch':
			points = getPasch(4);
			break;
			
		case 'Full_House':
			points = getFullHouse ();
			break;
			
		case 'Kleine_Strasse':
			points = getStrasse ("klein");
			break;
			
		case 'Grosse_Strasse':
			points = getStrasse ("gross");
			break;	
			
		case 'Chance':
			points = values[0]+values[1]+values[2]+values[3]+values[4];
			break;		
			
		case 'Kniffel':
			points = getPasch(5);
			break;
		
		default: alert("error");
				
	}

	if(points==0&&rolled>0) 
	{
		points = "----";
		field.innerHTML = points;
		rechneBonus();
		resetRound();
		return;
	}

	else if(points==0&&rolled==0)
	{
		points = null;
		field.innerHTML = points;
		rechneBonus();
		resetRound();
		return;
	}

	// Punkte zuweisen
	field.innerHTML = points;
	
	rechneBonus();

	// Gesamtpunktzahl erh�hen und in das HTML Element mit der ID score schreiben
	score += points;
	document.getElementById('score').innerHTML = score;

	// Runde zur�cksetzen
	resetRound();
}

/**
 * Einser bis Sechser berechnen
 *
 * @param number num
 * @return void
 */
function getEinserBisSechser(num) {
	var points = 0;

	for (var i = 0; i < values.length; i++) {
		if (values[i] == num) {
			points += num;
		}
	}
	oberePunktzahl += points;
	return points;
}

/**
 * Pasch berechnen
 *
 * @param number num
 * @return void
 */
function getPasch(num) {
	var points = 0;
	var richtig = 0;

	// @TODO Berechnen Sie einen Dreier- und Viererpasch
	
	for(var i=1;i<=5;i++)
	{
		for(var j=0;j<6;j++)
		{
			if(values[j]==i)
			{
				richtig++;
			}
		}

		if(richtig>=num)
		{
			points = values[0]+values[1]+values[2]+values[3]+values[4];
		} else {
			richtig = 0;
		}	
	}

	return points;
	
}

/**
 * Full House berechnen
 *
 * 
 * @return void
 */

 function getFullHouse() {
	var zahlen = [0, 0, 0, 0, 0, 0];
	var zweiOderDrei = [false, false];

	for(var a = 0; a < 5; a++) {
		zahlen[values[a] - 1]++;
	}
	
	for (var c = 0; c <= zahlen.length; c++) {
		if (zahlen[c] == 3) {
			zweiOderDrei[0] = true;
		}
		if (zahlen[c] == 2) {
			zweiOderDrei[1] = true;
		}
	}
	
	if (zweiOderDrei[0] == true && zweiOderDrei[1] == true) {
		return 25;
	}

	return 0; 
 }

 /**
 * Strasse berechnen
 *
 * 
 * @return void
 */
 
 function getStrasse(argu) {
	var zahlen = [false ,false ,false ,false ,false ,false];
	
	for(var i = 0; i < 5; i++) {
		zahlen[values[i] -1] = true;
	}
	
	//console.debug(zahlen);
	
	if(argu == "gross") {
		if (
			(zahlen[0] && zahlen[1] && zahlen[2] && zahlen[3] && zahlen[4])
			|| (zahlen[1] && zahlen[2] && zahlen[3] && zahlen[4] && zahlen[5]))
		{
			return 40;
		}
	}
	
	if(argu == "klein") {
		if(
			(zahlen[0] && zahlen[1] && zahlen[2] && zahlen[3])
			|| (zahlen[1] && zahlen[2] && zahlen[3] && zahlen[4])
			|| (zahlen[2] && zahlen[3] && zahlen[4] && zahlen[5]))
		{
			return 30;
		}
	}
	
	return 0;
 }
 
/**
 * Diese Runde zur�cksetzen
 *
 * @return void
 */
function resetRound() {
	var dices = document.getElementsByClassName('dice');

	for (var i = 0; i < dices.length; i++) {
		// Alle W�rfel loslassen
		dices[i].removeAttribute('data-hold');

		// Alle W�rfelwerte zur�cksetzen
		dices[i].value = 0;
	}

	// Alle gemerkten W�rfelwerte zur�cksetzen
	values = [];

	// @TODO Setzen Sie die Anzahl der get�tigten W�rfe zur�ck
	rolled = 0;
	turned = 0;
}

/**
 * W�rfel halten oder loslassen
 *
 * @param HTMLElement dice
 * @return void
 */
function toggleDice(dice) {
	// @TODO Verhindern Sie, dass die W�rfel gehalten oder losgelassen werden k�nnen, bevor mindestens einmal gew�rfelt wurde
	if(rolled>0) {
		if (dice.getAttribute('data-hold')) {
		// Das HTML Attribut "data-hold" existiert bereits und wird entfernt
		dice.removeAttribute('data-hold');
		} else {
		// Das HTML Attribut "data-hold" existiert noch nicht und wird gesetzt
		dice.setAttribute('data-hold', 1);
		}
	} else {
		return;
	}
	
	// Fokus auf diesen W�rfel entfernen
	dice.blur();
}

function rechneBonus() {
	var bonus = document.getElementById("bonus");
	
	if(oberePunktzahl >= 63 && bonus.innerHTML == "") {
		bonus.innerHTML = 35;
		score += 35;
	}
}

function writeBestenliste() {
	playerScore = JSON.parse(localStorage.getItem("scores"));

	var scores = document.getElementById("bestScores");
	scores.innerHTML = '';
	for (var i = 0; i < playerScore.length; i++) {
		var node = document.createElement('span');
		node.innerHTML = playerScore[i].name + ': ' + playerScore[i].score + '<br>';
		scores.appendChild(node);
	}
}

function bestenliste() {
	var eingabe = prompt("Name: ","");
	
	if(localStorage.getItem("scores")===null) {
		playerScore = [
			{
				"name": eingabe,
				"score": score
			}
		];
	}
	else {
		playerScore = JSON.parse(localStorage.getItem("scores"));
		playerScore.push({
			"name": eingabe,
			"score": score
		});
		
		playerScore.sort(function(a, b){
			return b.score - a.score;
		});

		playerScore.splice(5, playerScore.length - 5);
	}
	
	localStorage.setItem("scores",JSON.stringify(playerScore));
	
	writeBestenliste();
	
	
}